import React from 'react'
import {Route, createBrowserRouter, createRoutesFromElements, RouterProvider} from 'react-router-dom'
import HomePage from './Pages/HomePage';
import MainLayout from './layouts/MainLayout';
import JobsPages from './Pages/JobsPages';
import NotFoundPage from './Pages/NotFoundPage';
import JobPage, { JobLoader } from './Pages/JobPage';
import AddJobPage from './Pages/AddJobPage'; 
import EditJobPage from './Pages/EditJobPage';

const App = () => {

//Add JOB
const addJob = async (newJob) => {
  const res = await fetch('/api/jobs',{
    method:'POST',
    headers:{
      'Content-Type':'application/json'
    },
    body: JSON.stringify(newJob)
  });
  return;
}

//Delete JOB
const deleteJob = async(id) => {
  const res = await fetch(`/api/jobs/${id}`,{
    method:'DELETE'
  });
  return;
}

//Update JOB
const updateJob = async (job) => {
  const res = await fetch(`/api/jobs/${job.id}`,{
    method:'PUT',
    headers:{
      'Content-Type':'application/json'
    },
    body: JSON.stringify(job)
  });
  return;
}


const router = createBrowserRouter
(createRoutesFromElements(
  <Route path='/' element = {<MainLayout />} >
<Route index element={<HomePage/>} />
<Route path='/jobs' element={<JobsPages/>} />
<Route path='/add-job' element={<AddJobPage addJobSubmit={addJob} />} />
<Route path='/edit-job/:id' element={<EditJobPage updateJobSubmit={updateJob} />} loader={JobLoader} />
<Route path='/jobs/:id' element={<JobPage  deleteJob={deleteJob}/>} loader={JobLoader} />
<Route path='*' element={<NotFoundPage />} />
</Route>
)
);


  return <RouterProvider router={router}></RouterProvider>
}

export default App