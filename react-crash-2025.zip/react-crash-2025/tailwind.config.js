/** @type {import('tailwindcss').Config} */
export default {
 content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      fontFamily:{
        sans: ['Roboto','Sans Serif'],
      },
        gridTemplateColumns:{
          '70/30':'70% 28%',
        },
      },
  },
  plugins: [],
}

